"""
This script loads the level blockout helper script in Maya.

Original Author:
    Name: Darren Woodland Jr.
    Email: dkw34@drexel.edu
    Date Modified: 12/01/2024

This script was modified for the purposes of DIGM131-FA24 Final Exam.
"""
import sys
project_path = r"E:\DIGM131-FA24\Week 9\test\python" # Update this to the actual path of your python folder   
if project_path not in sys.path:
    sys.path.append(project_path)

import importlib
import level_blockout_helper
importlib.reload(level_blockout_helper)
level_blockout_helper.show_primitive_creator()