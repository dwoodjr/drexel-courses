"""
This script imports the level blockout data from a JSON file to Unity.

Original Author:
    Name: Darren Woodland Jr.
    Email: dkw34@drexel.edu
    Date Modified: 12/01/2024

This script was modified for the purposes of DIGM131-FA24 Final Exam.
"""

import UnityEngine as ue
import json
import os

class BlockoutImporter:
    def __init__(self, file_path):
        self.file_path = file_path

    def import_blockout(self):
        # TASK: Complete the if statement conditional check for an existing JSON file
        # Hint: the os module has a check for if a file path "exists"
        if not ___ (self.file_path):
            ue.Debug.LogError(f"File not found: {self.file_path}")
            return

        # Read the JSON file
        with open(self.file_path, 'r') as file:
            blockout_data = json.load(file)

        # Create the parent GameObject for imported data
        parent = ue.GameObject("BlockoutGroup")

        # Iterate through the blockout data and create the primitives
        for obj in blockout_data:
            obj_type = obj.get("type", "Cube") # get type, if not found, default to cube
            position = ue.Vector3(*obj["position"]) # Extract the object position from JSON
            scale = ue.Vector3(*obj["scale"]) # Extract the object scale from JSON

            # Create Unity GameObjects for the primitives
            if obj_type == "Cube":
                unity_obj = ue.GameObject.CreatePrimitive(ue.PrimitiveType.Cube)
            elif obj_type == "Sphere":
                unity_obj = ue.GameObject.CreatePrimitive(ue.PrimitiveType.Sphere)
            # TASK: Handle Cylinder, and unsupported types of Cone and Torus here.
            # Hint: Use ue.Debug.LogWarning() to log warnings. And 
            # Hint: What primitives are available in Unity that are similar to the ones in Maya?

            unity_obj.transform.position = ___ # TASK: Set position: JSON data for "position"
            unity_obj.transform.localScale = ___  # TASK: Set scale: JSON data for "scale"
            unity_obj.transform.parent = parent.transform  # Parent under BlockoutGroup

        ue.Debug.Log(f"Imported {len(blockout_data)} objects successfully!")

if __name__ == "__main__":
    importer = BlockoutImporter("E:/DIGM131-FA24/Week 9/test/data/blockout_data_test.json") #Replace with your JSON file path
    importer.import_blockout()