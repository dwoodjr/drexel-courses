"""
This script creates primitives in Maya using a Custom UI.

Original Author:
    Name: Darren Woodland Jr.
    Email: dkw34@drexel.edu
    Date Modified: 12/01/2024

This script was modified for the purposes of DIGM131-FA24 Final Exam.
"""

"""
Import statements needed for the script to run. Like random, maya.cmds, maya.OpenMayaUI, and PySide6.
"""
import random
import maya.cmds as cmds
import maya.OpenMayaUI as omui
from PySide6 import QtCore, QtWidgets
from PySide6.QtUiTools import QUiLoader
from shiboken6 import wrapInstance

"""
Base class for creating primitives. This is an abstract class that defines the interface for creating primitives.
Args:
    None
"""
class PrimitiveCreatorBase:
    """
    Abstract method for creating primitives. This method should be implemented by subclasses.
    Args:
        primitive_type (str): The type of primitive to create.
    """
    def create_primitive(self, primitive_type):
        raise NotImplementedError("This method should be implemented by subclasses")

"""
Class for creating primitives in Maya. Inherits from PrimitiveCreatorBase. This is where we define all functionality for creating primitives.
Args:
    PrimitiveCreatorBase (class): The base class for creating primitives.
"""
class MayaPrimitiveCreator(PrimitiveCreatorBase):
    """
    Dictionary of Maya commands for creating primitives. Using this dictionary, we can call the correct Maya command for each primitive type. 
    Making it easier to create primitives. and having cleaner code.
    Args:
        None
    Returns:
        dict: A dictionary of Maya commands for creating primitives.
    """
    PRIMITIVE_COMMANDS = {
        'cube': cmds.polyCube,
        'sphere': cmds.polySphere,
        'cylinder': cmds.polyCylinder,
        'cone': cmds.polyCone,
        'torus': cmds.polyTorus
    }

    """
    Method for generating a unique name by incrementing until an unused name is found.
    Args:
        base_name (str): The base name for the primitive.
        index (int): The index for the primitive.
    Returns:
        str: A unique name for the primitive.
    """
    def get_unique_name(self, base_name, index):
        """Generate a unique name by incrementing until an unused name is found"""
        while True:
            name = f"{base_name}_{index}"
            if not cmds.objExists(name):
                return name
            index += 1

    """
    Method for creating primitives and grouping them.
    Args:
        primitive_type (str): The type of primitive to create.
        count (int): The number of primitives to create.
        group_name (str): The name of the group to create.
    Returns:
        list: A list of the created primitives.
    """
    def create_primitives_and_group(self, primitive_type, count=1, group_name=None):
        created_primitives = []
        create_command = self.PRIMITIVE_COMMANDS.get(primitive_type)
        if create_command:
            for i in range(count):
                primitive = create_command()[0]
                unique_name = self.get_unique_name(primitive_type, i+1)
                new_name = cmds.rename(primitive, unique_name)
                created_primitives.append(new_name)

            if group_name:
                if cmds.objExists(group_name):
                    group_index = 1
                    while cmds.objExists(f"{group_name}_{group_index}"):
                        group_index += 1
                    group_name = f"{group_name}_{group_index}"
                cmds.group(created_primitives, name=group_name)

            return created_primitives
        else:
            cmds.warning('Unknown primitive type')

"""
Class for the UI. Inherits from QtWidgets.QMainWindow. This is where we define the UI and functionality.
Args:
    QtWidgets.QMainWindow (class): The base class for the UI.
"""
class PrimitiveCreatorUI(QtWidgets.QMainWindow):
    """
    Method for initializing method for the UI. 
    Note: Typically inherited classes need an __init__ method.
    Args:
        parent (QWidget): The parent widget.
    """
    def __init__(self, parent=None):
        super(PrimitiveCreatorUI, self).__init__(parent)

        ui_file_path = r"E:\\DIGM131-FA24\\Week 9\\test\\ui\\main.ui"

        ui_file = QtCore.QFile(ui_file_path)
        if not ui_file.exists():
            cmds.error(f"UI file not found: {ui_file_path}")
            return

        ui_file.open(QtCore.QFile.ReadOnly)
        loader = QUiLoader()
        self.ui = loader.load(ui_file, self)
        ui_file.close()

        self.setWindowTitle("Level Blockout Helper")
        self.setWindowFlags(QtCore.Qt.Window)

        self.countSpinBox = self.ui.countSpinBox
        self.groupNameLineEdit = self.ui.groupNameLineEdit
        self.ui.createPrimitiveButton.clicked.connect(self.create_primitives_with_color)
        self.ui.chooseColorButton.clicked.connect(self.select_color)
        self.ui.materialComboBox.addItems(["Lambert", "Blinn", "Phong"])

    def create_primitives_with_color(self):
        primitive_type = self.ui.primitiveComboBox.currentText().lower()
        material_type = self.ui.materialComboBox.currentText().lower()
        count = self.countSpinBox.value()
        group_name = self.groupNameLineEdit.text()
        randomize = self.ui.randDimsCheckBox.isChecked()

        material_name = cmds.shadingNode(material_type, asShader=True, name=f"{material_type}_{primitive_type}")
        shading_group = cmds.sets(name=f"{material_name}SG", empty=True, renderable=True, noSurfaceShader=True)
        cmds.connectAttr(f"{material_name}.outColor", f"{shading_group}.surfaceShader", force=True)

        color = self.ui.chooseColorButton.property("selectedColor")
        if color and color.isValid():
            red, green, blue = color.redF(), color.greenF(), color.blueF()
            if cmds.attributeQuery('color', node=material_name, exists=True):
                cmds.setAttr(f"{material_name}.color", red, green, blue, type="double3")
            if material_type in ["blinn", "phong"]:
                cmds.setAttr(f"{material_name}.specularColor", 0.5, 0.5, 0.5, type="double3")

        if randomize:
            dimX = (self.ui.minDimXSpinBox.value(), self.ui.maxDimXSpinBox.value())
            dimY = (self.ui.minDimYSpinBox.value(), self.ui.maxDimYSpinBox.value())
            dimZ = (self.ui.minDimZSpinBox.value(), self.ui.maxDimZSpinBox.value())
        else:
            dimX = self.ui.dimXSpinBox.value()
            dimY = self.ui.dimYSpinBox.value()
            dimZ = self.ui.dimZSpinBox.value()

        maya_primitive_creator = MayaPrimitiveCreator()
        created_primitives = maya_primitive_creator.create_primitives_and_group(primitive_type, count, group_name)

        if created_primitives:
            for primitive in created_primitives:
                shapes = cmds.listRelatives(primitive, shapes=True, fullPath=True)
                if shapes:
                    cmds.sets(shapes[0], edit=True, forceElement=shading_group)

                current_unit = cmds.currentUnit(query=True, linear=True)
                
                scale_factor = 1.0
                if current_unit == 'meter' or current_unit == 'm':
                    scale_factor = 100.0
                
                if randomize:
                    x_val = random.uniform(*dimX) * scale_factor
                    y_val = random.uniform(*dimY) * scale_factor
                    z_val = random.uniform(*dimZ) * scale_factor
                else:
                    x_val = dimX * scale_factor
                    y_val = dimY * scale_factor
                    z_val = dimZ * scale_factor

                history = cmds.listHistory(primitive)
                construction_node = next((node for node in history if cmds.nodeType(node).startswith('poly')), None)

                if construction_node:
                    if primitive_type == 'cube':
                        cmds.setAttr(f"{construction_node}.width", x_val)
                        cmds.setAttr(f"{construction_node}.height", y_val)
                        cmds.setAttr(f"{construction_node}.depth", z_val)
                    elif primitive_type == 'sphere':
                        radius = x_val / 2
                        cmds.setAttr(f"{construction_node}.radius", radius)
                    elif primitive_type == 'cylinder':
                        cmds.setAttr(f"{construction_node}.radius", x_val / 2)
                        cmds.setAttr(f"{construction_node}.height", y_val)
                    elif primitive_type == 'cone':
                        cmds.setAttr(f"{construction_node}.radius", x_val / 2)
                        cmds.setAttr(f"{construction_node}.height", y_val)
                    elif primitive_type == 'torus':
                        cmds.setAttr(f"{construction_node}.radius", x_val / 2)
                        cmds.setAttr(f"{construction_node}.sectionRadius", y_val / 4)

            message = f"Will create {count} {primitive_type}(s) with {material_type} material."
            if group_name:
                message += f" All primitives will be grouped under '{group_name}'."
            cmds.confirmDialog(
                title="Confirm Creation",
                message=message,
                button=["OK"]
            )
        else:
            cmds.warning("No primitives were created. Check the primitive type.")

    def select_color(self):
        color = QtWidgets.QColorDialog.getColor()
        if color.isValid():
            self.ui.chooseColorButton.setStyleSheet(f"background-color: {color.name()}; border: none;")
            self.ui.chooseColorButton.setProperty("selectedColor", color)

"""
Main function to show the UI Qt Widget
"""
def show_primitive_creator():
    global primitive_creator
    try:
        primitive_creator.close()
        primitive_creator.deleteLater()
    except:
        pass

    primitive_creator = PrimitiveCreatorUI()
    primitive_creator.show()

if __name__ == "__main__":
    show_primitive_creator()
