"""
This script exports the level blockout data to a JSON file.

Original Author:
    Name: Darren Woodland Jr.
    Email: dkw34@drexel.edu
    Date Modified: 12/01/2024

This script was modified for the purposes of DIGM131-FA24 Final Exam.
"""

import maya.cmds as cmds
import json
import os

class PrimitiveData:
    """Class responsible for handling primitive dimension calculations and data"""
    
    PRIMITIVE_TYPES = {
        # TASK: Fill in the mappings for each primitive type.
        'polyCube': 'Cube',
        'polySphere': 'Sphere',
        # Add mappings for 'polyCylinder', 'polyCone', and 'polyTorus'.
    }

    def get_dimensions(self, obj, shape_node):
        """
        Get the actual dimensions of the primitive from its construction history

        Args:
            obj (str): The name of the object to get the dimensions of
            shape_node (str): The name of the shape node to get the dimensions of
        
        Returns:
            list: A list of the dimensions of the primitive. Defaults to [1.0, 1.0, 1.0] if no construction history is found.
        """
        history = cmds.listHistory(obj)
        construction_node = next((node for node in history if cmds.nodeType(node).startswith('poly')), None)
        
        if not construction_node:
            return [1.0, 1.0, 1.0]
            
        node_type = cmds.nodeType(construction_node)
        dimension_methods = {
            'polyCube': self._get_cube_dimensions,
            'polySphere': self._get_sphere_dimensions,
            'polyCylinder': self._get_cylinder_dimensions,
            'polyCone': self._get_cylinder_dimensions,
            'polyTorus': self._get_torus_dimensions
        }
        
        method = dimension_methods.get(node_type)
        return method(construction_node) if method else [1.0, 1.0, 1.0]

    def _get_cube_dimensions(self, node):
        width = cmds.getAttr(f"{node}.width")
        height = cmds.getAttr(f"{node}.height")
        depth = cmds.getAttr(f"{node}.depth")
        return [width, height, depth]

    def _get_sphere_dimensions(self, node):
        radius = cmds.getAttr(f"{node}.radius")
        return [radius * 2, radius * 2, radius * 2]

    def _get_cylinder_dimensions(self, node):
        radius = cmds.getAttr(f"{node}.radius")
        height = cmds.getAttr(f"{node}.height")
        return [radius * 2, height, radius * 2]

    def _get_torus_dimensions(self, node):
        radius = cmds.getAttr(f"{node}.radius")
        section_radius = cmds.getAttr(f"{node}.sectionRadius")
        return [radius * 2, section_radius * 2, radius * 2]

    def get_primitive_type(self, history):
        """Determine the primitive type from construction history"""
        construction_node = next((node for node in history if cmds.nodeType(node).startswith('poly')), None)
        if construction_node:
            return self.PRIMITIVE_TYPES.get(cmds.nodeType(construction_node), 'Unknown')
        return 'Unknown'

class LevelBlockoutExporter:
    """Class responsible for exporting level blockout data"""
    
    def __init__(self):
        self.primitive_data = PrimitiveData()
        self.blockout_data = []

    def export(self, file_path):
        """
        Export the level blockout data to a JSON file

        Args:
            file_path (str): The path to the JSON file to export the data to
        """
        selected_objects = cmds.ls(selection=True, long=True)
        if not selected_objects:
            cmds.warning("No objects selected! Please select the primitives to export.")
            return

        self._process_selected_objects(selected_objects)
        self._write_to_json(file_path)

    def _process_selected_objects(self, selected_objects):
        self.blockout_data = []
        for obj in selected_objects:
            shape = cmds.listRelatives(obj, shapes=True, fullPath=True)
            if not shape:
                cmds.warning(f"Skipping {obj}, no shape found.")
                continue

            self._add_object_data(obj, shape[0])

    def _add_object_data(self, obj, shape):
        history = cmds.listHistory(obj)
        primitive_type = self.primitive_data.___  # TASK: Call the method to get primitive type.
        dimensions = self.primitive_data.___  # TASK: Call the method to get dimensions.
        position = cmds.xform(obj, query=True, worldSpace=True, translation=True)
        parent = cmds.listRelatives(obj, parent=True, fullPath=True)
        group_name = parent[0] if parent else None

        self.blockout_data.append({
            "type": primitive_type,
            "position": position,
            "scale": dimensions,
            "group": group_name
        })

    def _write_to_json(self, file_path):
        try:
            with open(file_path, 'w') as json_file:
                json.dump(self.blockout_data, json_file, indent=4)
            # TASK: Format the confirmation message with the file path.
            cmds.confirmDialog(
                title="___",
                message=f"___",
                button=["OK"]
            )
        except Exception as e:
            cmds.error(f"Failed to write to {file_path}: {e}")

def export_level_blockout(file_path=None):
    """Main function to export level blockout data"""
    exporter = LevelBlockoutExporter()
    exporter.export(file_path)

if __name__ == "__main__":
    # TASK: Update this file path to point to your Data directory.
    file_name = "blockout_data.json"
    file_path = os.path.join(r"<path_to_your_project>/Data", file_name)  # Replace <path_to_your_project>.
    export_level_blockout(file_path)
